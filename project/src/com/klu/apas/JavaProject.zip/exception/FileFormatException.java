	package com.klu.apas.exception;

	public class FileFormatException extends Exception {
	    public FileFormatException(String msg) {
	        super(msg);
	    }
	}


