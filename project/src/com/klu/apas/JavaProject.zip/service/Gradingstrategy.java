package com.klu.apas.service;
public interface Gradingstrategy {

	   public String computeGrade(int total);
	}


