package com.klu.apas.service;
	import java.util.List;
	import com.klu.apas.model.Student;

	public interface Analyticservice {

	   public static int calculateTotal(Student s) {
		// TODO Auto-generated method stub
		return 0;
	}
	  public  double calculateMean(List<Integer> marks);
	    public double calculateMedian(List<Integer> marks);
	    public double calculateStdDev(List<Integer> marks);
	  public static  String assignGrade(int total) {
		// TODO Auto-generated method stub
		return null;
	}
	}


