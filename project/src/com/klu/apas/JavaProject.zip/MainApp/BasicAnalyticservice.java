package com.klu.apas.MainApp;

import java.util.List;

import com.klu.apas.service.Analyticservice;
import com.klu.apas.strategy.SimpleGradingPolicy;

public class BasicAnalyticservice implements Analyticservice {

	

	public BasicAnalyticservice(SimpleGradingPolicy simpleGradingPolicy) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculateMean(List<Integer> marks) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calculateMedian(List<Integer> marks) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calculateStdDev(List<Integer> marks) {
		// TODO Auto-generated method stub
		return 0;
	}

}
