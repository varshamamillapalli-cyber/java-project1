package com.klu.apas.model;

public class Mark {

	public Mark(Object rollno, String subject, int m) {
		// TODO Auto-generated constructor stub
	}

	

	public Object getRollno() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getSubject() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getMarks() {
		// TODO Auto-generated method stub
		return 0;
	}

}
